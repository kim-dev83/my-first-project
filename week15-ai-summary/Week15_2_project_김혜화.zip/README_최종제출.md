# Week15_2 — AI 텍스트 요약 서비스 최종 제출 안내

## 프로젝트 요약
- 과제: 15-2주차 서비스 구현 및 배포 — **Level#3 자유주제 Cloud Service**
- 앱 이름: ✍️ 한눈요약
- 기술: Python, Streamlit, Gemini API
- 기능: 텍스트 입력, AI 요약(핵심 3줄/한 문장/자세히), TXT 저장
- **공개 URL:** https://week15-ai-summary.streamlit.app/
- **GitHub 소스(제출용 원본):** https://github.com/kim-dev83/my-first-project/tree/main/week15-ai-summary
- Streamlit 실행 경로: `week15-ai-summary/app.py` (branch: `main`)
- 검증일: 2026-10-25

## 실행 및 배포 확인
사용자 직접 캡처 기준: Windows 로컬에서 Streamlit 서버가 `http://localhost:8501`로 실행되었고, 로컬과 공개 Streamlit 앱 양쪽에서 `Gemini AI 요약 완료 (gemini-3.5-flash-lite)` 및 요약 결과가 확인되었다.

## 증빙자료
1. `01_로컬_터미널_네트워크주소_가림.png` — 로컬 실행 콘솔 및 Local URL. Network URL 전체 비공개 처리.
2. `02_로컬_AI요약_실행완료.png` — 로컬 주소와 Gemini 요약 결과, TXT 저장 확인.
3. `03_공개배포_AI요약_실행완료.png` — 공개 웹 앱의 실제 Gemini 요약 결과.
4. `04_Streamlit_Secrets_API키_완전가림.png` — `GEMINI_API_KEY`가 Streamlit Secrets에 설정된 화면. **실제 키 전체 가림**.
5. `05_Gemini_API_무료등급_사용량.png` — Default Gemini Project, 무료 등급 및 API 사용량/오류/토큰 통계.

## 실행 방법 (Windows)
```powershell
cd week15-ai-summary
python -m pip install -r requirements.txt
python -m streamlit run app.py --server.address 127.0.0.1
```
브라우저 접속: http://localhost:8501

실제 AI 사용을 위해 `.streamlit/secrets.toml`에 **본인 키를 직접 설정** (해당 비밀 파일은 제출하거나 GitHub에 커밋하지 않음):
```toml
GEMINI_API_KEY = "실제_API_키_여기에_입력"
```

## 배포 구성
GitHub 저장소의 앱을 Streamlit Community Cloud에 연결. `Secrets`에 `GEMINI_API_KEY`를 안전하게 등록했고, 모델 기본값을 `gemini-3.5-flash-lite`로 변경하여 API 404 오류를 해결함.

## 비용 및 비밀정보 관리 (사실 관계 구분)
- Google AI Studio에서 해당 프로젝트에 **무료 등급**이 표시된 화면과 API 사용 통계를 캡처했다.
- 무료 등급 확인은 **유료 결제 지출 상한을 별도로 설정했다는 증빙이 아니다**. 별도 월 지출 한도 설정은 확인되지 않았다.
- 공개 앱은 소유자 API 할당량을 사용할 수 있으므로 주기적 사용량 모니터링과 필요시 배포 접근 제한 권장.
- API 키/로컬 사설 IP는 제출 캡처에서 가렸으며 키 원문이나 `secrets.toml`은 제출물에 포함하지 않았다.

## 제출 판단
공개 URL을 통한 서비스 구현·배포와 로컬 실행, 실제 AI 요약 동작의 증빙은 확보됨. 강의에서 **별도 비용 상한 설정 화면을 필수**로 요구한다면 무료 등급 사용 기록만으로 그 요건 충족을 단정할 수 없으므로 담당 교수자에게 무료 등급 대체 증빙 허용 여부 확인 필요.
